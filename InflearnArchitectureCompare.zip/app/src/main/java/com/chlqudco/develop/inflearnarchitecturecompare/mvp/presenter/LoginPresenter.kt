package com.chlqudco.develop.inflearnarchitecturecompare.mvp.presenter

import com.chlqudco.develop.inflearnarchitecturecompare.mvp.model.User


interface LoginPresenter {
    val user: User

    fun login()
}